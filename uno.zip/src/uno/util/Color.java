package uno.util;


public enum Color {
	GREEN, BLUE, YELLOW, RED
}
