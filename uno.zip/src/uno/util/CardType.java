package uno.util;

public enum CardType {
    VALUE, REVERSE, SKIP, TAKE
}
